"Here it is a sales invoice sample"
